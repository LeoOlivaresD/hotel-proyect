package cl.duoc.hotel.dto;

import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class DashboardStats {
    private long reservasActivas;
    private long habitacionesOcupadas;
    private double ingresosMes;
    private long checkinshoy;
}
